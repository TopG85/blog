console.log("Life, The Universe and Everything!");

document.addEventListener('DOMContentLoaded', function() {
    console.log('CodeStar Blog JavaScript loaded');
});
